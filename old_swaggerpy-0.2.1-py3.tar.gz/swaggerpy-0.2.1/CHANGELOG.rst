0.2.0 (2013-10-28)
------------------
- Add close() methods to client and http_client.

0.1.0 (2013-10-24)
------------------

- Initial release
