0.1.3 (2014-09-08)
------------------

- Allow arbitrary data to be passed to event callbacks
- Fixed misspelling bug in deviceStates resource

0.1.2 (2014-08-12)
------------------

- Added support for the deviceStates resource
- Added support for the mailboxes resource
- Renamed playback resource to playbacks (matches change in Asterisk)

0.1.1 (2013-10-28)
------------------

- Adding author_email to setup.py

0.1.0 (2013-10-28)
------------------

- Initial release
