#!/usr/bin/env python

#
# Copyright (c) 2013, Digium, Inc.
#

import unittest


class UtilTest(unittest.TestCase):
    pass

if __name__ == '__main__':
    unittest.main()
