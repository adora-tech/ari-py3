client Package
==============

:mod:`client` Package
---------------------

.. automodule:: swaggerpy.client
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`client` Module
--------------------

.. automodule:: swaggerpy.client.client
    :members:
    :undoc-members:
    :show-inheritance:

