.. swagger-py documentation master file, created by
   sphinx-quickstart on Wed Oct 16 09:33:48 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to swagger-py's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 2

   swaggerpy
   swaggerpy.client

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

